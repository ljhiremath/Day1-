﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q7
{

    class Program
    {
        static void Main(string[] args)
        {
            Child Cobj = new Child();
            Cobj.fatherFunction();
            Cobj.motherFunction();
        }
    }
}
