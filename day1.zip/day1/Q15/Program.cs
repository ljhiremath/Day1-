﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q15
{
    class Program
    {
        static void Main(string[] args)
        {product objProduct = new product();
            objProduct.Accept();
            while (objProduct.QuantityAvailable != 0)
            {
                Console.WriteLine("press a for update existing product");
                Console.WriteLine("press b to buy product");
                Console.WriteLine("press c to display product");
                Console.WriteLine("press d to exit ");
                char option;
                option = Console.ReadLine()[0];
                if (option == 'a')
                {
                    objProduct.Accept();
                    objProduct.Display();
                }
                else if (option == 'b')
                {
                    objProduct.Shopping();
                    objProduct.Display();
                }
                else if (option == 'c')
                {
                    objProduct.Display();
                }
                else if (option == 'd')
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine("Invalid option");
                }

                
            } 
        }
        }
    }

