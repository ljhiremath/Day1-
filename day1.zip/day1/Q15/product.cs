﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q15
{
    class product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public Double UnitPrice { get; set; }
        public int QuantityAvailable { get; set; }
        public void Accept()
        {
            this.ProductId = 1;
            this.QuantityAvailable = 3;
            Console.WriteLine("Enter product name");
            this.ProductName = Console.ReadLine();
            Console.WriteLine("Enter Description");
            this.Description = Console.ReadLine();
            Console.WriteLine("Enter unit price");
            this.UnitPrice = Int32.Parse(Console.ReadLine());

        }
        public void Shopping()
        {
            this.QuantityAvailable = this.QuantityAvailable - 1;
            Console.WriteLine("Your order is successfully placed");
        }
        public void Display()
        {
            Console.WriteLine("Product id : " + ProductId + " Product name : " + ProductName + " Description : " + Description + " Unit Price : " + UnitPrice + " Available Quantity : " + QuantityAvailable);
        }
    }
}

