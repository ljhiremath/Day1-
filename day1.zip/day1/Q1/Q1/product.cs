﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q1
{
    class product
    {
        int _productID;
        string _productName;
        double _unitPrice;
        int _quantity;

        public void Accept()
        {
            Console.WriteLine("enter product id:");
            _productID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter product name:");
            _productName = Console.ReadLine();

            Console.WriteLine("enter unit price:");
            _unitPrice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter quantity:");
            _quantity= Convert.ToInt32(Console.ReadLine());
          }
        public void display()
        {

            Console.WriteLine("the product id:{0}", _productID);
            Console.WriteLine("the product name:{0}", _productName);
            Console.WriteLine("the unit price:{0}", _unitPrice);
            Console.WriteLine("the quantity:{0}", _quantity);
        
        
        }

 
    }
}