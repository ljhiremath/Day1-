﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Electronic class inherited by Mobile");
            Mobile m = new Mobile();

            Console.WriteLine("Electronic class inherited by Computer");
            Computer c = new Computer();
        }
    }
}
