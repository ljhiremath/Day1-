﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q8
{
    class ElectronicsProducts
    {int _productID;
        string _productName;

        public ElectronicsProducts()
        {
            _productID = 101;
            _productName = "camera";
            Console.WriteLine("Product ID:" + _productID);
            Console.WriteLine("Product Name:" + _productName);
        }
       
    
    }
    class Mobile:ElectronicsProducts
    {
        int _mobileCode;
        string _mobileModel;

        public Mobile()
        {
            _mobileCode = 1012;
            _mobileModel = "nokia";
            Console.WriteLine("Mobile Code:" + _mobileCode);
            Console.WriteLine("Mobile Model:" + _mobileModel);
        }
      
    }
    class Computer:ElectronicsProducts
    {
        int _computerID;
        string _computerModel;
        public Computer()
        {
            _computerID = 1013;
            _computerModel = "dell";
            Console.WriteLine("Computer ID:" + _computerID);
            Console.WriteLine("Computer Model:" + _computerModel);
            Console.ReadKey();
        }

       
    }
    }

