﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q12
{
    class duck
    {
        private int _option;
        public void Menu()
        {
            Console.WriteLine("Press 1 for Feeding your Duck");
            Console.WriteLine("Press 2 for Feeding your Toy Duck");
            _option = Convert.ToInt32(Console.ReadLine());

            if (_option == 1)
            {
                Myduck objMyDuck = new Myduck();
                objMyDuck.Eat();
            }
            else if (_option == 2)
            {
                Toyduck objtoyDuck = new Toyduck();
                objtoyDuck.Eat();
            }
            else
            {
                Console.WriteLine("Sorry invalid option");
            }
        }
    }
}
