﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q12
{
    class Program
    {

        static void Main(string[] args)
        {
            duck objDuck = new duck();
            objDuck.Menu();
        }
    }
}

