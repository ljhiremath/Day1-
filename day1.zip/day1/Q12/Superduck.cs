﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q12
{
    class Superduck
    { public virtual void Eat() 
        {
            Console.WriteLine("Eat() from SuperDuck Class");
        }
   
    }
    class Myduck : Superduck
    {
        public override void Eat()
        {
            Console.WriteLine("I am eating food");
        }
    }

    class Toyduck : Superduck
    {
        public override void Eat()
        {
            Console.WriteLine("My food is electrons");
        }
    }


}
