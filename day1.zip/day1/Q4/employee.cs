﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q4
{
    class employee
    {
         
        public int Employeeid
        {
            get;
            set;
        }
        public string EmployeeName
        {
            get;
            set;
        }
        public double EmployeeSalary
        {
            get;
            set;
        }
                 
    }
}
