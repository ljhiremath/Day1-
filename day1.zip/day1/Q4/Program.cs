﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q4
{
    class Program
    {
        static void Main(string[] args)
        {
            employee e = new employee();
            e.Employeeid = 101;
            e.EmployeeName = "Charu";
            e.EmployeeSalary = 12000;

            Console.WriteLine("Employee ID:" + e.Employeeid);
            Console.WriteLine("Employee Name:" + e.EmployeeName);
            Console.WriteLine("Employee Salary:" + e.EmployeeSalary);
            Console.ReadKey();
        }
    }
}
