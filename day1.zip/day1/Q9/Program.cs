﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q9
{
    class Program
    {public void area(int radius)
        {
           Console.WriteLine("circle AREA:"+(3.14 * radius * radius));
        
        }
        public void area(int Base,double height)
        {
        Console.WriteLine("triangle AREA:"+ (0.5 * Base * height)); 
        }
        public void area(int length, int breadth)
        {
            Console.WriteLine("rectangle AREA:"+(length * breadth));
        }
        static void Main(string[] args)
        {
            Program p = new Program();
            
            int val,val2;
            Console.WriteLine("press 1.Area of Circle 2.Triangle 3.Rectangle");
            int temp = Convert.ToInt32(Console.ReadLine());
            switch (temp)
            {
                case 1:
                    Console.WriteLine("enter radius");
                    val = Convert.ToInt32(Console.ReadLine());
                     p.area(val);
                   
                    break;
                case 2:
                    Console.WriteLine("enter length and height");
                    val = Convert.ToInt32(Console.ReadLine());
                    val2 = Convert.ToInt32(Console.ReadLine());
                    p.area(val,val2);
                    
                    break;
                case 3:
                    Console.WriteLine("enter base and height");
                    val = Convert.ToInt32(Console.ReadLine());
                    val2 = Convert.ToInt32(Console.ReadLine());
                    p.area(val, val2);
                   
                    break;
            
            }

        }
    }
        
}
