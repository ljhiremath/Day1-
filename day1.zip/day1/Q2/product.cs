﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q2
{
    class product
    {
        int _productID;
        string _productName;
        double _unitPrice;
        int _quantity;
        public product()
        { 
        this._productID=402;
        this. _productName="bottle";
         this._unitPrice=4000;
          this._quantity = 3;
        }

        public product(int _productID, string _productName, double _unitPrice, int _quantity)
        {
            int pID, qty;
            double price;
            string pName;
            pID = _productID;
            qty = _quantity;
            price = _unitPrice;
            pName = _productName;


            Console.WriteLine("the product id:{0}", pID);
            Console.WriteLine("the product name:{0}", pName);
            Console.WriteLine("the unit price:{0}", price);
            Console.WriteLine("the quantity:{0}", qty);
        
        
        }

        public void Accept()
        {
            Console.WriteLine("enter product id:");
            _productID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter product name:");
            _productName = Console.ReadLine();

            Console.WriteLine("enter unit price:");
            _unitPrice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter quantity:");
            _quantity= Convert.ToInt32(Console.ReadLine());
          }
        public void display()
        {

            Console.WriteLine("the product id:{0}", _productID);
            Console.WriteLine("the product name:{0}", _productName);
            Console.WriteLine("the unit price:{0}", _unitPrice);
            Console.WriteLine("the quantity:{0}", _quantity);
        
        
        }

 
    }
}
    
