﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            product objP1 = new product();
            product objP2 = new product(401,"cbr",7000,4);
            Console.ReadKey();
        }
    }
}
