﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q5
{
    class Product
    {public int _productID;
        public string _productName;
       public double _unitPrice;
       public int _quantity;

        public void Accept()
        {
            Console.WriteLine("enter product id:");
            _productID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter product name:");
            _productName = Console.ReadLine();

            Console.WriteLine("enter unit price:");
            _unitPrice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter quantity:");
            _quantity= Convert.ToInt32(Console.ReadLine());
          }
        public void display()
        {

            Console.WriteLine("the product id:{0}", _productID);
            Console.WriteLine("the product name:{0}", _productName);
            Console.WriteLine("the unit price:{0}", _unitPrice);
            Console.WriteLine("the quantity:{0}", _quantity);

        }
        }
class Mobile :Product
{ string _cameraDetails = "front camera";
    string _modelDetails=" samsung";
    string _BatteryDetails="4130Amph";
   public void Display()
    {
        Console.WriteLine("Camera details :{0}",_cameraDetails);
        Console.WriteLine("Model details :{0}",_modelDetails);
        Console.WriteLine("battery details :{0}",_BatteryDetails);
        
    }
}
 
    }
    

