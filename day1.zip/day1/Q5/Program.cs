﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q5
{
    class Program
    {
        static void Main(string[] args)
        {
            Mobile objMob = new Mobile();
            objMob.Accept();
             objMob.display();
           objMob.Display();
            Console.ReadKey();
        }
    }
}
