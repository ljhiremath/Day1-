﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q6
{
    class Program
    {
        static void Main(string[] args)
        {
            Smartphone objSp = new Smartphone();
            objSp.Accept();
            objSp.Display();
            objSp.display();
            objSp.disp();
            Console.ReadKey();
            
        }
    }
}
