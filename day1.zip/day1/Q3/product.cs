﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q3
{
    class product
    {
        //int productID;
        //string productName;
        //double unitPrice;
        //int quantity;

        private int r;
        private string r1;

        public int productID
        {
            
            get {  return(401);}
        
        }
        public double unitPrice
        {
            
            get { return (1000); }

        }
        public string productName
        {
            set
            {
                r1 = value;
            }
        }
        public int quantity
        {
            
            set
            {
                r = value;
            }
        }





    }
}
