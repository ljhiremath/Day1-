﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            product objP1 = new product();
            Console.WriteLine(objP1.productID);
            Console.WriteLine(objP1.unitPrice);
            Console.WriteLine(objP1.productName = "mrf");
           Console.WriteLine(objP1.quantity = 4);
            Console.ReadKey();


        }
    }
}
