﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q10
{
    class Program
    {  public int add(int num1, int num2)
        {
            return (num1+num2);
        }
        public int add(int num1, int num2,int num3)
        {
            return(num1+num2+num3);
        }

        public int Subtract(int num1, int num2)
        {
            return (num1 - num2);
        }
        public int Subtract(int num1, int num2, int num3)
        {
            return (num1 - num2 - num3);
        }
        public int Multiplication(int num1, int num2)
        {
            return (num1 * num2);
        }
        public int Multiplication(int num1, int num2, int num3)
        {
            return (num1 * num2 * num3);
        }
    }
        static void Main(string[] args)
        {
            int val1, val2,val3;
            int result;

            Program p = new Program();
            Console.WriteLine("press 1.addition of 2 numbers 2.For 3 numbers");
            Console.WriteLine("press 3.Subtraction of 2 numbers 4.For 3 numbers");
            Console.WriteLine("press 5.Multiplication of 2 numbers 6.For 3 numbers");
            int temp = Convert.ToInt32(Console.ReadLine());
            switch (temp)
            { 
                case 1:
                    Console.WriteLine("enter two numbers");
                    val1 = Convert.ToInt32(Console.ReadLine());
                    val2 = Convert.ToInt32(Console.ReadLine());
                    result=p.add(val1,val2);
                    Console.WriteLine("sum:"+result);
                    break;
                case 2:
                    Console.WriteLine("enter three numbers");
                    val1 = Convert.ToInt32(Console.ReadLine());
                    val2 = Convert.ToInt32(Console.ReadLine());
                    val3 = Convert.ToInt32(Console.ReadLine());
                   result= p.add(val1, val2,val3);
                   Console.WriteLine("sum:" + result);
                    break;
                case 3:
                    Console.WriteLine("enter two numbers");
                    val1 = Convert.ToInt32(Console.ReadLine());
                    val2 = Convert.ToInt32(Console.ReadLine());
                    result = p.Subtract(val1, val2);
                    Console.WriteLine("Difference:" + result);
                    break;
                case 4:
                    Console.WriteLine("enter three numbers");
                    val1 = Convert.ToInt32(Console.ReadLine());
                    val2 = Convert.ToInt32(Console.ReadLine());
                    val3 = Convert.ToInt32(Console.ReadLine());
                    result = p.Subtract(val1, val2, val3);
                    Console.WriteLine("difference:" + result);
                    break;
                case 5:
                    Console.WriteLine("enter two numbers");
                    val1 = Convert.ToInt32(Console.ReadLine());
                    val2 = Convert.ToInt32(Console.ReadLine());
                    result = p.Multiplication(val1, val2);
                    Console.WriteLine("Product:" + result);
                    break;
                case 6:
                    Console.WriteLine("enter three numbers");
                    val1 = Convert.ToInt32(Console.ReadLine());
                    val2 = Convert.ToInt32(Console.ReadLine());
                    val3 = Convert.ToInt32(Console.ReadLine());
                    result = p.Multiplication(val1, val2, val3);
                    Console.WriteLine("Product:" + result);
                    break;

            }
            Console.ReadKey();
        }
           
    
    

